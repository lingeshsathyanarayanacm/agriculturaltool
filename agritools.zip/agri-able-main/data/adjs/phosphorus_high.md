Excess phosphorus in soil can inhibit growth of mycorrhizae, which help the plants absorb water and nutrients. To address excessive soil phosphorus, begin by avoiding future phosphorus applications, which include eliminating organic composts and manures. If organic nitrogen sources or mulches are needed, use very low phosphorus producs such as blood meal or pine barch mulch.

**References**

- https://counties.agrilife.org/valverde/files/2014/11/Phosphorus-Too-Much-Plants-May-Suffer.pdf