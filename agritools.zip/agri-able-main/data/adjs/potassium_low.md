Potassium is required to help plants grow faster, be more drought resistant, fight off disease, and resist pests. To address potassium deficiency, the following can be done:

- Using fertilizer high in potassium, or potash fertilizer
- Using compost made primarily from food byproducts, such as banana peels

**References**

- https://www.gardeningknowhow.com/garden-how-to/soil-fertilizers/plants-potassium.htm