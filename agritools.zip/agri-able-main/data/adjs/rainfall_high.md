Slow down the rate of raindrops to reduce the impact to the soil. Leave at least 30% of crop residue on the surface, or adding cover crops to the fields can help.

**References**

- https://www.canr.msu.edu/news/managing_the_impact_of_rain_on_your_field_crops