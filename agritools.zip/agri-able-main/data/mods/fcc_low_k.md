> Potassium is required to help plants grow faster, be more drought resistant, fight off disease, and resist pests.

**Remedy**

Use fertilizer high in potassium, or potash fertilizer, Explore using compost made primarily from food byproducts, such as banana peels.

**References**

- https://www.gardeningknowhow.com/garden-how-to/soil-fertilizers/lowering-potassium-levels.htm	
- https://www.gardeningknowhow.com/garden-how-to/soil-fertilizers/plants-potassium.htm